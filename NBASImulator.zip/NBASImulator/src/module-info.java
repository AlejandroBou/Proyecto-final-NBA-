/**
 * 
 */
/**
 * 
 */
module NBASImulator {
	requires java.desktop;
}