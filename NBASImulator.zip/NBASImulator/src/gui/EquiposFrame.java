// EquiposFrame.java
package gui;

import javax.swing.*;

public class EquiposFrame extends JFrame {
    public EquiposFrame() {
        setTitle("Lista de Equipos");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
