// SimulacionFrame.java
package gui;

import javax.swing.*;

public class SimulacionFrame extends JFrame {
    public SimulacionFrame() {
        setTitle("Simulación de Jornadas");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
