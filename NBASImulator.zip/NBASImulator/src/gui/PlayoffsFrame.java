// PlayoffsFrame.java
package gui;

import javax.swing.*;

public class PlayoffsFrame extends JFrame {
    public PlayoffsFrame() {
        setTitle("Simulación de Playoffs");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
